package com.example.dava

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
